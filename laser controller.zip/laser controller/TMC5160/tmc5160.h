#ifndef _TMC5160_H
#define _TMC5160_H

//#define TMC5160_FRAME_LEN  8

#include <stdint.h>

extern const uint8_t Z_AXIS;
extern const uint8_t Z_AXIS_HS;

//extern uint8_t data_array[8];

void TMC5160_TxEnable(void);
void TMC5160_RxEnable(void);

void TMC5160_init_Config(void);

void TMC5160_CLEAR(void);
void TMC5160_Read(uint8_t axis, uint8_t Reg_Addr);

uint32_t TMC5160_Initialize_Reset(void);

#endif
