#include "stm32f3xx_hal.h"
#include "usart.h"
#include "tmc5160.h"

#include <string.h>
#include <stdio.h>
#include <stdarg.h>

extern uint8_t buffer;
extern uint8_t UART_BUF;
extern uint8_t UART_FLAG;
extern uint8_t UART_INT;

extern uint8_t Receive_data[7];   // received data from USB-UART5

const uint8_t Z_AXIS=0X03;
const uint8_t Z_AXIS_HS=0x04;

/*Addressing multiple TMC5160 */
uint8_t Read_Data[8];
uint8_t addr_array[8]={0x05,0x00,0x83,0x00,0x00,0x02,0x80,0x4a};  		//set node addr 0x00
	
/*Configure the motor 80*/
uint8_t data_array[8]={0x05,0x00,0xec,0x00,0x01,0x00,0xc5,0x3f};      //CHOPCONF: Chopper Configuration, TOFF=5,HSTRT=4,HEND=1,CHM=0,TBL1=1,MRES=0 
uint8_t seting_array[8]={0x05,0x00,0x90,0x00,0x01,0x11,0x05,0x2c};    //Velocity dependent:ihold=5,irun=17,,ihold delay=1

uint8_t A1_array[8]={0x05,0x00,0xa4,0x00,0x00,0x03,0xe8,0x2a};    //SET A1@1000
uint8_t V1_array[8]={0x05,0x00,0xa5,0x00,0x00,0xC3,0x50,0xd1};    //SET V1@50000
uint8_t amax_array[8]={0x05,0x00,0xa6,0x00,0x00,0x19,0x74,0xe9};  //set amax@6516
uint8_t vmax_array[8]={0x05,0x00,0xa7,0x00,0x00,0xe9,0x04,0x97};    //set vmax@59652, 25rpm,0.9,12mhz
uint8_t Dmax_array[8]={0x05,0x00,0xa8,0x00,0x00,0x19,0x74,0x77};    //set Dmax@6516
uint8_t ramp_array[8]={0x05,0x00,0xa0,0x00,0x00,0x00,0x00,0xc6};  //00 is positioning mode (using all A, D and V parameters) 

uint8_t D1_array[8]={0x05,0x00,0xaa,0x00,0x00,0x29,0xe8,0xec};   //set D1@10728
uint8_t VSTOP_array[8]={0x05,0x00,0xab,0x00,0x00,0x00,0x0a,0x1c};   //vstop @10

/*Configure working mode*/
uint8_t Motor_Step_a[8]={0x05,0x00,0xad,0x00,0x00,0x64,0x00,0xd7};   //set the position@25600, XTARGET

//uint8_t SW_MODE_a[8]={0x05,0x80,0xb4,0x00,0x00,0x08,0x09,0x3c};   // soft stop the motor
uint8_t SW_MODE_a[8]={0x05,0x00,0xb4,0x00,0x00,0x00,0x09,0x42};   // hard stop the motor

uint8_t Actual_Clear_a[8]={0x05,0x00,0xa1,0x00,0x00,0x00,0x00,0x51}; //clear actual
uint8_t Target_Clear_a[8]={0x05,0x00,0xad,0x00,0x00,0x00,0x00,0x07}; //clear target
uint8_t Hold_Mode_a[8]={0x05,0x00,0xa0,0x00,0x00,0x00,0x03,0x88}; //hold mode
uint8_t PWMCONF_a[8]={0x05,0x00,0xF0,0x00,0x04,0x01,0xC8,0x97}; // 04-StealthChop
uint8_t TPWMTHRS_a[8]={0x05,0x00,0x93,0x00,0x00,0x00,0xff,0xfc}; // TSTEP>=TPWMTHRS
uint8_t TPWMTHRS_a_hs[8]={0x05,0x00,0x93,0x00,0x00,0x00,0x8d,0x11}; 
uint8_t ENPWM_MODE_a[8]={0x05,0x00,0x80,0x00,0x00,0x00,0x04,0xa9};  //TMC5160 StealChop voltage PWM mode enable




void TMC5160_TxEnable(void)
{
    HAL_GPIO_WritePin(GPIOB, _USART1_5160_EN_Pin, GPIO_PIN_SET);
}


void TMC5160_RxEnable(void)
{
    HAL_GPIO_WritePin(GPIOB, _USART1_5160_EN_Pin, GPIO_PIN_RESET);
}


void TMC5160_init_Config(void)
{
	USART1_Send_Array(data_array,8);
	USART1_Send_Array(seting_array,8);

	USART1_Send_Array(A1_array,8);
	USART1_Send_Array(V1_array,8);
	USART1_Send_Array(amax_array,8);
	USART1_Send_Array(vmax_array,8);	
	USART1_Send_Array(Dmax_array,8);
	USART1_Send_Array(ramp_array,8);
	USART1_Send_Array(D1_array,8);	
	USART1_Send_Array(VSTOP_array,8);
	
	USART1_Send_Array(SW_MODE_a,8);
	USART1_Send_Array(ENPWM_MODE_a,8);
	USART1_Send_Array(TPWMTHRS_a,8);
	USART1_Send_Array(PWMCONF_a,8);
}

//void TMC5160_CLEAR(uint8_t motor_addr)
void TMC5160_CLEAR(void)
{
	USART1_Send_Array(Hold_Mode_a,8);
	USART1_Send_Array(Actual_Clear_a,8);
	USART1_Send_Array(Target_Clear_a,8);
	USART1_Send_Array(ramp_array,8);
	
}


void TMC5160_Read(uint8_t axis, uint8_t Reg_Addr)
{

}

uint32_t TMC5160_Initialize_Reset(void)
{
	uint32_t ret_flag=0; 						// ���ڴ洢��λ�����Ĭ��ʧ��
	uint32_t max_retry_count = 5; // ����Դ�����������Ҫ������


	USART1_Send_CMD_AutoCRC(0x00,0x20,0x00,0x00,0x00,0x01);   //switch to velocity mode
	HAL_Delay(10);	
	
	USART1_Send_CMD_AutoCRC(0x00,0x27,0x00,0x07,0x86,0xa0);   //reconfigure the VMAX
	USART1_Send_CMD_AutoCRC(0x00,0x26,0x00,0x00,0x32, 0x00); // Configure acceleration (AMAX)
	HAL_Delay(10);	

	//���븴λ���ѭ��
    for (uint32_t retry_count = 0; retry_count < max_retry_count; retry_count++) 
    {
        if (HAL_GPIO_ReadPin(POS_REFL_GPIO_Port, POS_REFL_Pin) == GPIO_PIN_RESET)
        {
            // 3.1 ���ֹͣ
            USART1_Send_CMD_AutoCRC(0x00, 0x27, 0x00, 0x00, 0x00, 0x00); // Stop motor
            HAL_Delay(10);

            // 3.2 ���㵱ǰλ��
            USART1_Send_CMD_AutoCRC(0x00, 0x21, 0x00, 0x00, 0x00, 0x00); // Clear position

            // 3.3 �����Զ���λ����������ѡ��
            USART1_Send_CMD_AutoCRC(0x00, 0x2D, 0x00, 0x00, 0x00, 0x00); // Disable jump after positioning mode

            // 3.4 �л��ض�λģʽ
            USART1_Send_CMD_AutoCRC(0x00, 0x20, 0x00, 0x00, 0x00, 0x00); // Switch back to Positioning mode

            ret_flag = 1; // ��λ�ɹ�
            break;
        }
        HAL_Delay(2); // С�ӳ٣����ڱ����Ƶ���
    }
		
		if (ret_flag == 0) 
    {
        // ����������Դ�����δ�ɹ���λ
        // ���ڴ˴����Ӵ������߼����紮�����������Ϣ��
				UART5_SendByte(0xE0);

    }

    return ret_flag;

}



